/* معرض صور احتياطي يستخدم نفس أصول استديو فزعة الموثوقة. */
import { useState, useCallback, useEffect, useRef } from "react";
import { STUDIO_SLIDES } from "@/lib/studio";

const AUTO_INTERVAL = 4000;

export default function GalleryStudio() {
  const [index, setIndex] = useState(0);
  const total = STUDIO_SLIDES.length;
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const next = useCallback(() => setIndex((i) => (i + 1) % total), [total]);

  useEffect(() => {
    timerRef.current = setInterval(next, AUTO_INTERVAL);
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [next]);

  const goTo = useCallback(
    (i: number) => {
      setIndex(i);
      if (timerRef.current) clearInterval(timerRef.current);
      timerRef.current = setInterval(next, AUTO_INTERVAL);
    },
    [next]
  );

  return (
    <section className="relative w-full bg-[#0d0b07]">
      <div className="relative w-full overflow-hidden" style={{ aspectRatio: "1920 / 480" }}>
        {STUDIO_SLIDES.map((slide, i) => (
          <img
            key={slide.id}
            src={slide.src}
            alt={slide.titleAr}
            loading={i === 0 ? "eager" : "lazy"}
            decoding={i === 0 ? "auto" : "async"}
            className="absolute inset-0 h-full w-full object-contain transition-opacity duration-700"
            style={{ opacity: i === index ? 1 : 0 }}
          />
        ))}
        <div className="absolute inset-0 bg-gradient-to-t from-black/30 via-transparent to-black/10 pointer-events-none" />
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2 z-10">
          {STUDIO_SLIDES.map((slide, i) => (
            <button
              key={slide.id}
              type="button"
              onClick={() => goTo(i)}
              aria-label={`الصورة ${i + 1}`}
              className={`h-2 rounded-full transition-all ${i === index ? "w-6 bg-[#C9A227]" : "w-2 bg-white/50 hover:bg-white/80"}`}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
