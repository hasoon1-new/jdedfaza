export interface StudioSlide {
  id: string;
  src: string;
  titleAr: string;
  titleEn: string;
}

export const STUDIO_SLIDES: StudioSlide[] = [
  { id: "family-year", src: "/manus-storage/studio-slide-01_3627ad91.webp", titleAr: "عام الأسرة 2026", titleEn: "Year of the Family 2026" },
  { id: "membership-cards", src: "/manus-storage/studio-slide-02_21375242.webp", titleAr: "بطاقات فزعة للعائلات", titleEn: "Fazaa cards for families" },
  { id: "discount-membership", src: "/manus-storage/studio-slide-03_9924a4d8.webp", titleAr: "عضوية الخصومات للأسر المقيمة", titleEn: "Discount membership for resident families" },
];

export function wrapStudioIndex(index: number, length = STUDIO_SLIDES.length) {
  return ((index % length) + length) % length;
}
